
package proiectvalentin;




public class CoadaV {
    private NodeV head;
    private NodeV tail;
    
    public CoadaV() {
        this.head = null;
        this.tail = null;
    }
    
    public void adaugare(int value){
        NodeV newNode = new NodeV(value);
        if(tail != null){
            tail.next = newNode;
        }
        tail = newNode;
        if(head == null){
            head = newNode;
        }
    }
    
    
    public void stergere(){
        if(head == null){
            System.out.println("Coada este goala!!!");
        }
        head = head.next;
        if(head == null){
            tail = null;
        }
        
    }
    
    public String afisare() {
    if (head == null) {
        return "Coada este goala!!\n";
    }

    StringBuilder sb = new StringBuilder();
    NodeV curr = head;
    while (curr != null) {
        sb.append(curr.data).append(" -> ");
        curr = curr.next;
    }
    sb.append("null\n");

    return sb.toString();
}
    
    public boolean isEmpty(){
        return head == null;
    }
    
    public NodeV getHead(){
        if(head == null)
            System.out.println("Coada este goala!!");
        
         return this.head;
    }
    
    
}
