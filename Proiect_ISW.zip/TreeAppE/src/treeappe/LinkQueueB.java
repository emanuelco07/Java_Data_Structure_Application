package treeappe;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Bianca
 */
public class LinkQueueB {

    public FirstLastListB theList;

    public LinkQueueB() // constructor
    {
        theList = new FirstLastListB();
    } 

    public boolean isEmpty() // true if queue is empty
    {
        return theList.isEmpty();
    }

    public void insert(long j) // insert, rear of queue
    {
        theList.insertLast(j);
    }

    public long remove() // remove, front of queue
    {
        return theList.deleteFirst();
    }

    public void displayQueue() {
        System.out.print("Queue (front-->rear): ");
        theList.displayList();
    }
    public LinkQueueB copyQueue() {
    LinkQueueB newQueue = new LinkQueueB();
    LinkB current = this.theList.first;
    while (current != null) {
        newQueue.insert(current.dData);
        current = current.next;
    }
    return newQueue;
}
}
