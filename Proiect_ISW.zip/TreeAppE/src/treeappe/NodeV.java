package proiectvalentin;

public class NodeV {
    int data;
    NodeV next;
    CoadaV subCoada;
    
    NodeV(int data) {
        this.data = data;
        this.next = null;
        this.subCoada = new CoadaV();
    }
}
