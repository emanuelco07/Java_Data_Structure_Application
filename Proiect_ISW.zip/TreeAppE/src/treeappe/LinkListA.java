package treeappe;

/**
 *
 * @author ANDREI
 */
public class LinkListA {
    protected LinkA first;
    private GUI_A gui;
    
    public LinkListA(GUI_A gui){
        first = null;
        this.gui = gui;
    }
    
    public boolean isEmpty(){
        return (first==null);
    }
    
    public void insertLast(int id){
        LinkA newLink = new LinkA(id, gui);
        
        if(isEmpty()){
            first = newLink;
            return;
        }
        
        LinkA current = first;
        while(current.next != null){
            current = current.next;
        }
        
        current.next = newLink;
    }
    
    public void displayList(){
        LinkA current = first;
        while(current != null){
            current.displayLink();
            current = current.next;
        }
        System.out.println("");
    }
}
