package treeappe;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author Bianca
 */
public class FirstLastListB {

    public LinkB first; // ref to first 
    public LinkB last; // ref to last 

    public FirstLastListB() // constructor
    {
        first = null; 
        last = null;
    }

    public boolean isEmpty() // true if no links
    {
        return first == null;
    }

    public void insertLast(long dd) // insert at end of list
    {
        LinkB newLink = new LinkB(dd); // make new link
        if (isEmpty()) 
        {
            first = newLink; 
        } else {
            last.next = newLink; 
        }
        last = newLink; 
    }

    public long deleteFirst() // delete first link
    { 
        long temp = first.dData;
        if (first.next == null) // if only one item
        {
            last = null; 
        }
        first = first.next; 
        return temp;
    }

    public void displayList() {
        LinkB current = first; 
        while (current != null) 
        {
            current.displayLink(); // print data
            current = current.next; 
        }
        System.out.println("");
    }

}
