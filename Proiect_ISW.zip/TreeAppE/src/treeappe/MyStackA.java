
package treeappe;

/**
 *
 * @author ANDREI
 */
public class MyStackA {
    protected int maxSize;
    protected Object[] stackArray;
    protected int top;
    
    public MyStackA(int s){
        maxSize = s;
        stackArray = new Object[maxSize];
        top = -1;
    }
    
    public void push(Object j){
        stackArray[++top] = j;
    }
    
    public Object pop(){
        return stackArray[top--];
    }
    
    public boolean isEmpty(){
        return (top == -1);
    }
}
