/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package treeappe;

/**
 *
 * @author Bianca
 */
public class LinkListTB {
      protected LinkB first;
     public LinkListTB(){
        first = null;
    }
    
    public boolean isEmpty(){
        return (first==null);
    }
    
    public void insertFirst(int id){
        LinkB newLink = new LinkB(id);
        newLink.next = first;
        first = newLink;
    }
    
    public void displayList(){
        LinkB current = first;
        while(current != null){
            current.displayLink();
            current = current.next;
        }
        System.out.println("");
    }

}
