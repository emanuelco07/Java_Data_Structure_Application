package treeappe;

public class NodeE {

    public int iData;
    public NodeE leftChild;
    public NodeE rightChild;

    public NodeE(int data) {
        iData = data;
    }

    public void displayNode() {
        System.out.print("{" + iData + "}");
    }
}
