package treeappe;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class TreeE {
    protected NodeE root;
    private GUI_E gui;
    private Scanner sc = new Scanner(System.in);
    
    public TreeE(GUI_E gui){
        root = null;
        this.gui = gui;
    }
    
//    private Node createRec(){
//        System.out.print("Este nod NULL? (n/N pentru NU): ");
//        String input = sc.nextLine();
//        
//        if(input.equalsIgnoreCase("n")){
//            System.out.print("Cheie: ");
//            int k = Integer.parseInt(sc.nextLine());
//            
//            Node aux = new Node(k);
//            
//            System.out.println("Fiul stang al lui " + k + ":");
//            aux.leftChild = createRec();
//            
//            System.out.println("Fiul drept al lui " + k + ":");
//            aux.rightChild = createRec();
//            
//            return aux;
//        }
//        else {
//            return null;
//        }
//    }
    
    private NodeE createRec() {
        int confirm = JOptionPane.showConfirmDialog(
                null,
                "Este nod NULL?",
                "Creare nod",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.NO_OPTION) { // utilizatorul zice NU, deci vrem un nod
            String input = JOptionPane.showInputDialog(
                    null,
                    "Cheie: ");
            int k = Integer.parseInt(input);

            NodeE aux = new NodeE(k);

            JOptionPane.showMessageDialog(null, "Fiul stâng al lui " + k + ":");
            aux.leftChild = createRec();

            JOptionPane.showMessageDialog(null, "Fiul drept al lui " + k + ":");
            aux.rightChild = createRec();

            return aux;
        } else {
            return null;
        }
    }
    
    public void createTree(){
        this.root = createRec();
    }
    
    public void displayTree()
    {
        MyStackE globalStack = new MyStackE(100);
        globalStack.push(root);
        int nBlanks = 32;
        boolean isRowEmpty = false;
        while(isRowEmpty == false){
            MyStackE localStack = new MyStackE(100);
            isRowEmpty = true;
            for(int j=0; j< nBlanks; j++){
                gui.add_text_in_text_area1(" ");
            }
            while(globalStack.isEmpty() == false){
                NodeE temp = (NodeE)globalStack.pop();
                if(temp != null){
                    gui.add_text_in_text_area1(String.valueOf(temp.iData));
                    localStack.push(temp.leftChild);
                    localStack.push(temp.rightChild);
                    if(temp.leftChild != null || temp.rightChild != null){
                        isRowEmpty = false;
                    }
                    } else {
                        gui.add_text_in_text_area1("--");
                        localStack.push(null);
                        localStack.push(null);
                    }
                    for(int j=0; j<=nBlanks*2-2; j++){
                        gui.add_text_in_text_area1(" ");
                    }
                }
                gui.add_text_in_text_area1("\n");
                nBlanks /= 2;
                while(localStack.isEmpty() == false){
                    globalStack.push(localStack.pop());
            }
            gui.add_text_in_text_area1("\n");
        }
        gui.add_text_in_text_area1("\n");
    }
    
    int roads = 0; //pentru a numarul numarul de cai
    public LinkListE[] buildHashTableForRoads(){
        roads = 0; //punem roads pe 0 ca atunci cand apelam functia sa ne reseteze numarul de drumuri
        contor_roads(root);
        
        LinkListE[] table = new LinkListE[roads];
        
        for(int i=0;i< roads;i++)
            table[i] = new LinkListE(gui);
        
        int[] path = new int[1001]; //vector de 1001 elemente pentru a memora in el caile partiale
        buildRec(root, table, path, 0); //folosin path pentru a memora caile
        return table;
    }
    
    int leaf = 0; //folosim pentru a numara frunzele (consideram prima frunza - prima cale)

    private void buildRec(NodeE current, LinkListE[] table, int[] path, int pathLen){
        if(current != null)
        {
            path[pathLen++] = current.iData;
            if(current.leftChild == null && current.rightChild == null)
            {
                for(int i = 0; i < pathLen; i++)
                    table[leaf].insertLast(path[i]); //adaugam in tabel nodurile
                leaf++; //marim numarul de frunze gasite
            }
            else
            {
                buildRec(current.leftChild, table, path, pathLen);
                buildRec(current.rightChild, table, path, pathLen);
            }
        }
    } 
    
    //pentru a numara numarul de cai
    private void contor_roads(NodeE current)
    {
        if(current == null)
            return;
        
        if(current.leftChild == null && current.rightChild == null)
            roads++;
        
        contor_roads(current.leftChild);
        contor_roads(current.rightChild);
    }
}
