
package proiectvalentin;


import java.awt.BorderLayout;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import treeappe.Main_GUI;




public class GUI_V extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(GUI_V.class.getName());
    private int cnt =0;
    private int currRow =0;
    private int currCol =0;
    private JPanel dynamicPanel;
    
    public GUI_V() {
        initComponents();
        setLayout(new BorderLayout());
        dynamicPanel = new JPanel(new FlowLayout());
        add(dynamicPanel, BorderLayout.SOUTH);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        inputColoane = new javax.swing.JTextField();
        inputRanduri = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentHidden(java.awt.event.ComponentEvent evt) {
                formComponentHidden(evt);
            }
        });

        jButton1.setText("Submit");
        jButton1.addActionListener(this::jButton1ActionPerformed);

        jLabel1.setText("Nr. Coloane");

        jLabel2.setText("Nr. Randuri");

        inputColoane.addActionListener(this::inputColoaneActionPerformed);

        inputRanduri.addActionListener(this::inputRanduriActionPerformed);

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        jButton2.setText("Inapoi");
        jButton2.addActionListener(this::jButton2ActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addGap(18, 18, 18)
                            .addComponent(inputColoane, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel2)
                            .addGap(18, 18, 18)
                            .addComponent(inputRanduri)))
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addGap(78, 78, 78)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 384, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(inputColoane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(inputRanduri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addComponent(jButton1)
                        .addGap(28, 28, 28)
                        .addComponent(jButton2))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(109, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // în actionPerformed la Submit
        int n = Integer.parseInt(inputRanduri.getText());
        int m = Integer.parseInt(inputColoane.getText());
        
        MatriceV mat = new MatriceV(m,n);
        JTextField tf = new JTextField(10);
        JButton bt = new JButton("val");
        
        
        
        //Coada principala :D
        CoadaV coadaPrincipala = new CoadaV();
        
        
        //coadaPrincipala.afisare();
        dynamicPanel.add(tf);
        dynamicPanel.add(bt);
        dynamicPanel.revalidate();
        dynamicPanel.repaint();
        jButton1.setEnabled(false);
        
        bt.addActionListener(e->{
            int valMatrice = Integer.parseInt(tf.getText());
            mat.setValoare(currRow, currCol, valMatrice);
            tf.setText("");
            
            currCol++;
            if(currCol == m){
                currCol = 0;
                currRow++;
            }
            
            
            if(currRow == n){ 
                bt.setEnabled(false);
                
                jTextArea2.append(mat.afisare());
                System.out.println(mat.afisare());
                
                mat.matriceCozi();
                jTextArea2.append(mat.afisareCozi());
                
                int af = JOptionPane.showConfirmDialog(
                this,
                "Procesul s-a terminat. Vrei sa reincepi?",
                "Finalizat",
                JOptionPane.YES_NO_OPTION
                );
                if (af == JOptionPane.YES_OPTION) {
                inputRanduri.setText("");
                inputColoane.setText("");
                jTextArea2.setText("");
                currRow = 0;
                currCol = 0;
                jButton1.setEnabled(true);
                dynamicPanel.removeAll();
                dynamicPanel.revalidate();
                dynamicPanel.repaint();
    }
            }   
        });
        
        
        inputRanduri.setText("");
        inputColoane.setText("");
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void inputColoaneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputColoaneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inputColoaneActionPerformed

    private void inputRanduriActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inputRanduriActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_inputRanduriActionPerformed

    private void formComponentHidden(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentHidden
        // tODO add your handling code here:
        
    }//GEN-LAST:event_formComponentHidden

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        java.awt.EventQueue.invokeLater(() -> new Main_GUI().setVisible(true));
        
        this.setVisible(false);
    }//GEN-LAST:event_jButton2ActionPerformed

    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> new GUI_V().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JTextField inputColoane;
    public javax.swing.JTextField inputRanduri;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea2;
    // End of variables declaration//GEN-END:variables
}
