package treeappe;

public class LinkE {
    public int iData;
    public LinkE next;
    private GUI_E gui;
    
    public LinkE(int id, GUI_E gui){
        iData = id;
        this.gui = gui;
    }
    
    public void displayLink(){
        gui.add_text_in_text_area2(iData + " ");
    }
}
