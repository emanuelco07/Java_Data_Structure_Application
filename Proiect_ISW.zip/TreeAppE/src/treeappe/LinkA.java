
package treeappe;

/**
 *
 * @author ANDREI
 */
public class LinkA {
    public int iData;
    public LinkA next;
    public GUI_A gui;
    
    public LinkA(int id, GUI_A gui){
        iData = id;
        this.gui = gui;
    }
    
    public void displayLink(){
        gui.add_text_in_text_area2(iData + " ");
    }
}
