
package treeappe;

import java.util.Scanner;
import javax.swing.JOptionPane;


/**
 *
 * @author ANDREI
 */
public class TreeA {
    protected NodeA root;
    private GUI_A gui;
    private Scanner sc = new Scanner(System.in);
    
    public TreeA(GUI_A gui){
        root = null;
        this.gui = gui;
    }
    
    /*private Node createRec(){
        System.out.print("Este nod NULL? (n/N pentru NU): ");
        String input = sc.nextLine();
        
        if(input.equalsIgnoreCase("n")){
            System.out.print("Cheie: ");
            int k = Integer.parseInt(sc.nextLine());
            
            Node aux = new Node(k);
            
            System.out.println("Fiul stang al lui " + k + ":");
            aux.leftChild = createRec();
            
            System.out.println("Fiul drept al lui " + k + ":");
            aux.rightChild = createRec();
            
            return aux;
        }
        else {
            return null;
        }
    }*/
    
    private NodeA createRec(){
        int confirm = JOptionPane.showConfirmDialog(
                null, 
                "Este nod NULL?", 
                "Creare nod", 
                JOptionPane.YES_NO_OPTION);
        
        if(confirm == JOptionPane.NO_OPTION){
            String input = JOptionPane.showInputDialog(
            null, 
            "Cheie: ");
            int k = Integer.parseInt(input);
            
            NodeA aux = new NodeA(k);
            
            JOptionPane.showMessageDialog(null, "Fiul stang al lui " + k + ":");
            aux.leftChild = createRec();
            
            JOptionPane.showMessageDialog(null, "Fiul drept al lui " + k + ":");
            aux.rightChild = createRec();
            
            return aux;
        } else {
            return null;
        }
    }
    

    
    public void createTree(){
        this.root = createRec();
    }
    
    public void displayTree()
    {
        MyStackA globalStack = new MyStackA(100);
        globalStack.push(root);
        int nBlanks = 32;
        boolean isRowEmpty = false;
        while(isRowEmpty == false){
            MyStackA localStack = new MyStackA(100);
            isRowEmpty = true;
            for(int j=0; j< nBlanks; j++){
                gui.add_text_in_text_area1(" ");
            }
            while(globalStack.isEmpty() == false){
                NodeA temp = (NodeA)globalStack.pop();
                if(temp != null){
                    gui.add_text_in_text_area1(String.valueOf(temp.iData));
                    localStack.push(temp.leftChild);
                    localStack.push(temp.rightChild);
                    if(temp.leftChild != null || temp.rightChild != null){
                        isRowEmpty = false;
                    }
                } else {
                    gui.add_text_in_text_area1("--");
                    localStack.push(null);
                    localStack.push(null);
                }
                for(int j=0; j<=nBlanks*2-2; j++){
                    gui.add_text_in_text_area1(" ");
                }
            }
            gui.add_text_in_text_area1("\n");
            nBlanks /= 2;
            while(localStack.isEmpty() == false){
                globalStack.push(localStack.pop());
            }
            gui.add_text_in_text_area1("\n");
        }
        gui.add_text_in_text_area1("\n");
    }
    
    public LinkListA[] buildHashTableByChildren(){
        LinkListA[] table = new LinkListA[3];
        
        for(int i=0;i<3;i++)
            table[i] = new LinkListA(gui);
        
        buildRecRSD(root, table);
        
        return table;
    }
    
    private void buildRecRSD(NodeA current, LinkListA[] table){
        if(current == null) return;
        
        int children = 0;
        if(current.leftChild != null) children++;
        if(current.rightChild != null) children++;
        
        table[children].insertLast(current.iData);
        
        buildRecRSD(current.leftChild, table);
        buildRecRSD(current.rightChild, table);
        
    }
}
