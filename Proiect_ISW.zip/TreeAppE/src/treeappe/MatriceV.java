
package proiectvalentin;

import java.util.Scanner;


public class MatriceV {
    private int n;
    private int m;
    private int[][] matrix;
    private CoadaV coadaPrincipala;

   
    public  MatriceV(int coloane, int randuri){
        //System.out.println("Introdu numar de coloane: ");
         this.n = randuri;
        //System.out.println("Introdu numarul de linii: ");
        this.m = coloane;
        this.matrix = new int[n][m];
    }
    public void setValoare(int i, int j, int valoare){
        matrix[i][j] = valoare;
    }
    
    
    public String afisare() {
        StringBuilder sb = new StringBuilder();
        sb.append("Matricea este: \n");
        for (int i = 0; i < n; i++) {
            for (int j =0; j <m; j++) {
                
                sb.append(matrix[i][j]).append("  ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }
    
    public void matriceCozi(){
        coadaPrincipala= new CoadaV();
       
        for(int i=1;i<=n;i++){
           coadaPrincipala.adaugare(i);
        }
         NodeV curr = coadaPrincipala.getHead();
        for(int i=0; i<n;i++){
            for(int j=0;j<m;j++){
                curr.subCoada.adaugare(matrix[i][j]); 
            }
             curr = curr.next;
        }
        }
    
    public String afisareCozi() {
    StringBuilder sb = new StringBuilder();
    NodeV curr = coadaPrincipala.getHead();

    sb.append("\nCoada principala: ");
    sb.append(coadaPrincipala.afisare());
    sb.append("\n");

    
    while (curr != null) {
        sb.append(curr.data).append("\n↓\n");
        sb.append("Subcoada: ");

        
        NodeV sub = curr.subCoada.getHead();
        while (sub != null) {
            sb.append(sub.data).append(" -> ");
            sub = sub.next;
        }
        sb.append("null\n");

        curr = curr.next;
    }

    return sb.toString();
}
    
    public CoadaV getCoadaPrincipala(){
        return coadaPrincipala;
    }
    
}
