/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package treeappe;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author Bianca
 */
public class TreeB {

    protected NodeB root;
    protected int[] a;
    protected int index = 0;
    private Scanner sc = new Scanner(System.in);

    public TreeB() {
        root = null;
    }

    public NodeB createRec() {
        int confirm = JOptionPane.showConfirmDialog(
                null,
                "Este nod NULL?",
                "Creare nod",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.NO_OPTION) {
            String input = JOptionPane.showInputDialog(
                    null,
                    "Cheie");

            int k = Integer.parseInt(input);

            NodeB aux = new NodeB(k);

            JOptionPane.showMessageDialog(null, "Fiul stang al lui " + k + ":");//
            aux.leftChild = createRec();

            JOptionPane.showMessageDialog(null, "Fiul drept al lui " + k + ":");
            aux.rightChild = createRec();

            return aux;
        } else {
            return null;
        }
    }

    public void createTree() {
        this.root = createRec();
    }

    public String displayTreeString() {
        StringBuilder stb = new StringBuilder();
        StackTreeB globalStack = new StackTreeB(100);
        globalStack.push(root);
        int nBlanks = 32;
        boolean isRowEmpty = false;
        while (isRowEmpty == false) {
            StackTreeB localStack = new StackTreeB(100);
            isRowEmpty = true;
            for (int j = 0; j < nBlanks; j++) {
                stb.append(' ');
            }
            while (globalStack.isEmpty() == false) {
                NodeB temp = (NodeB) globalStack.pop();
                if (temp != null) {
                    stb.append(temp.iData);
                    localStack.push(temp.leftChild);
                    localStack.push(temp.rightChild);
                    if (temp.leftChild != null || temp.rightChild != null) {
                        isRowEmpty = false;
                    }
                } else {
                    stb.append("--");
                    localStack.push(null);
                    localStack.push(null);
                }
                for (int j = 0; j <= nBlanks * 2 - 2; j++) {
                    stb.append(' ');
                }
            }
            stb.append("\n");
            nBlanks /= 2;
            while (localStack.isEmpty() == false) {
                globalStack.push(localStack.pop());
            }
        }
        return stb.toString();
    }



    public void initArray() {
        a = new int[10001];
        index = 0;
    }

    public int get_index() {
        return this.index;
    }

    public void fillFromTree(LinkQueueB q) {
        fillRec(root);
        fill_from_Queue(q);
    }

    public void fill_from_Queue(LinkQueueB q) {
        while (!q.isEmpty() && index < a.length) {
            int val = (int) q.remove();

            if (!isInArray(a, index, val)) {
                a[index++] = val;
            }
        }
    }

    public void fillRec(NodeB current) {
        if (current == null) {
            return;
        }

        fillRec(current.leftChild);

        if (!isInArray(a, index, current.iData)) {
            a[index++] = current.iData;      // adaugă nodul în vector
        }
        fillRec(current.rightChild);
    }

    public void addElemInQueue(LinkQueueB q) {
        while (!q.isEmpty() && index < a.length) {
            int val = (int) q.remove();
            if (!isInArray(a, index, val)) {
                a[index++] = val;
            }
        }
    }

    public boolean isInArray(int[] arr, int length, int val) {
        for (int i = 0; i < length; i++) {
            if (arr[i] == val) {
                return true;
            }
        }
        return false;
    }

    public int[] getArray() {
        return a;
    }
    //intersectie
    public boolean existsInTree(NodeB current, int val) {
    if (current == null) return false;
    if (current.iData == val) return true;
    return existsInTree(current.leftChild, val) ||
           existsInTree(current.rightChild, val);
}
public int[] intersectieCuCoada(LinkQueueB q) {
    initArray(); // resetam vectorul a si index
    LinkB current = q.theList.first;

    while (current != null) {
        int val = (int) current.dData;

        // daca val exista in arbore si nu e deja in vector
        if (existsInTree(root, val) && !isInArray(a, index, val)) {
            a[index++] = val;
        }

        current = current.next;
    }

    return a;
}
public void insertNodeInTree(int val) {
    root = insertRec(root, val);
}
 private NodeB insertRec(NodeB current, int val) {
        if (current == null) {
            return new NodeB(val);
        }
        if (val < current.iData) {
            current.leftChild = insertRec(current.leftChild, val);
        } else if (val > current.iData) {
            current.rightChild = insertRec(current.rightChild, val);
        }
        return current;
    }
public void buildTreeFromArray(int[] arr, int len) {
    root = null; // resetam arborele
    for (int i = 0; i < len; i++) {
        insertNodeInTree(arr[i]);
    }
}
}
