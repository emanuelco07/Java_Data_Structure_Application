package treeappe;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Bianca
 */
public class LinkB {
    
public long dData; // data item
public LinkB next; 


public LinkB(long d) // constructor
{ dData = d; }

public void displayLink() // display this link
{ System.out.print(dData + ""); }
} 

