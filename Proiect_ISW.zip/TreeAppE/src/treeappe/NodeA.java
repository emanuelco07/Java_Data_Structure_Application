
package treeappe;

/**
 *
 * @author ANDREI
 */
public class NodeA {
    public int iData;
    public NodeA leftChild;
    public NodeA rightChild;
    
    public NodeA(int data){
        iData = data;
    }
    
    public void displayNode(){
       System.out.print("{" + iData + "}");
   }
}
