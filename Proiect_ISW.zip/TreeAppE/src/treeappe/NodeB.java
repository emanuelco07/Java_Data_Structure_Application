/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package treeappe;

/**
 *
 * @author Bianca
 */
public class NodeB {
    public int iData; // data item (key)
    public NodeB leftChild; // this node’s left child
    public NodeB rightChild; // this node’s right child

 public NodeB(int data){
        iData = data;
    }
public void displayNode() 
{
 System.out.print("{" + iData + "}");

}}

