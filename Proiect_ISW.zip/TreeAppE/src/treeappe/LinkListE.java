package treeappe;

public class LinkListE {
   protected LinkE first;
   private GUI_E gui;
    
    public LinkListE(GUI_E gui){
        this.gui = gui;
        first = null;
    }
    
    public boolean isEmpty(){
        return (first==null);
    }
    
    public void insertLast(int id){
        LinkE newLink = new LinkE(id, gui);
        
        if(isEmpty()){
            first = newLink;
            return;
        }
        
        LinkE current = first;
        while(current.next != null){
            current = current.next;
        }
        
        current.next = newLink;
    }
    
    public void displayList(){
        LinkE current = first;
        while(current != null){
            current.displayLink();
            current = current.next;
        }
    } 
}
